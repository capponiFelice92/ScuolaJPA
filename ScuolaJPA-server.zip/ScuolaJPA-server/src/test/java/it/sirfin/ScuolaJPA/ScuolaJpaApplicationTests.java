package it.sirfin.ScuolaJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScuolaJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
